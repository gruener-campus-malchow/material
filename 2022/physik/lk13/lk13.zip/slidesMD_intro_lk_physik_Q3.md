---
# LK Pysik 13

2021-2022

---

# Intro

* Vorstellung
* Bürokratie
* Kommunikation

---

## Vorstellungsrunde

* Sind alle da? Sonst Rückmeldung
* Was wollen wir voneinander wissen?

---

## Bürokratie

* DSB-Zugang Schüler
* Zeugnis Unterschrift
* Stammdatenblatt ausgeben und ggf. überarbeiten
* Schulbescheinigungen
* SalzH-Abfrage
    * PC
    * Netzanbindung
    * Übersicht an Fr. Stendal
    * Einverständniserklärungen Lernraum, BBB siehe Protokoll
  
---

## Kommunikationswege

* Jahrgangslernraum-Kurs darstellen und durchgehen
* DSB - aktuelle Infos
* Schwarzes Brett

---

## Termine
* Liste aus Mail
* Abiturplan
    * alle Termine sind verbindlich!!!
    * Handy oder Planer raus
    * Feiertage aus religiösen Gründen

---
    
* Fehlzeitenregelung
    * Entschuldigungszettel müssen im Vorfeld vom Tutor unterschrieben sein
    * Krankmeldung morgens bis 8:00 Uhr
    * Sekretariat
    * Tutor
    * Erster Akt nach Gesundung
    * bei Klausur auch an OKO
        * 3 Tage nach Meldung, ärztliches Attest einreichen (digital)
---

* Dienstag Stundenplan: Keine Fragen zum Stundenplan an Hr. Hammermeister sondern Sprechstunde bei Fr. Stendal
* Hausaufgabe (Planer raus): Abiturplan und Stundenplan abgleichen
* Daheimgebliebene in Studienfahrtenwoche: Vertretungsunterricht
  * Zwei freie Plätze je Fr. Sernau Ostseefahrt, Fr. Stendal Amrum
* Kurssprecherwahl in 2. Woche
---

## Belehrungen

(siehe Folien OKO)

* Handyregelung
* Laptopregelung aus TK kolportieren
* Oberstufenraum als **Arbeitsraum** für JG 12+
* Mülltrennung

---

## Sonstiges

* AG-Leitung möglich, bis Freitag (13.8.) bei Fr. Altmann melden, Honorar u.U. möglich
* Belobigungen
* V. PK... alles Okay? Literaturliste? Gliederung?

---

auf bald

---

Markdeep also allows captions on Gravizo graphs and newlines within
the URL itself:

![Figure [graph]: A more complex graph example](http://g.gravizo.com/svg?
 digraph G {
   main -> parse -> execute;
   main -> init;
   main -> cleanup;
   execute -> make_string;
   execute -> printf
   init -> make_string;
   main -> printf;
   execute -> compare;
 })

---
