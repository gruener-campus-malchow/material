'use strict';

alert("Hello World");
